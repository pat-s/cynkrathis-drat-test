library(testthat)
library(cynkrathis)

test_check("cynkrathis")
